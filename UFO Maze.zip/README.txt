  The goal of the game is to look for the golden pebbles.
  You win when you collect all of them. 
  A message will appear on screen, after that you can
simply close the window.

  Controls: WASD or the arrow keys
  Warning: You might want to reduce the volume